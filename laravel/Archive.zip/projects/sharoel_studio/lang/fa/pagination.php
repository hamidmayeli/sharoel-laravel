<?php

declare(strict_types=1);

return [
    'next' => 'بعدی &raquo;',
    'previous' => '&laquo; قبلی',
];
