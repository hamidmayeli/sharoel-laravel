<?php

declare(strict_types=1);

return [
    'next' => 'Next &raquo;',
    'previous' => '&laquo; Previous',
];
