<?php

declare(strict_types=1);

return [
    'next' => 'Weiter &raquo;',
    'previous' => '&laquo; Zurück',
];
