<x-admin-dashboard-layout>
    <livewire:gallery/>
</x-admin-dashboard-layout>
