
<x-app-layout>
    @include('app.home.partials.intro')
    @include('app.home.partials.categories')
    @include('app.home.partials.plans')
    @include('app.home.partials.slider')
</x-app-layout>
