<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="my-32 px-5 grid grid-cols-1 lg:grid-cols-3 lg:gap-x-5 gap-y-5">
        <img class="rounded-2xl size-full object-cover" src=<?php echo e(asset('images/about.jpg')); ?> alt="">
        <div class="col-span-2 h-full max-w-4xl flex flex-col justify-center">
            <h1 class="text-4xl font-bold mb-10">ABOUT SHAROEL STUDIO</h1>
            <p class="mb-5"><?php echo e(__('about_description_intro')); ?></p>
            <p class="mb-5"><?php echo e(__('about_description_story')); ?></p>
            <p class="mb-5"><?php echo e(__('about_description_experience')); ?></p>
            <p class="mb-5"><?php echo e(__('about_description_services')); ?></p>
            <p class="mb-5"><?php echo e(__('about_description_closing')); ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/app/about/index.blade.php ENDPATH**/ ?>