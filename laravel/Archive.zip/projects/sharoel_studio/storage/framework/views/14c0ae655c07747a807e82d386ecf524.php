<div>
    <div class="columns-1 md:columns-2 lg:columns-3 gap-4 space-y-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative group" x-data="{ shown: false }" x-intersect.once="shown = true">
                <img src="<?php echo e($image->getFirstMedia('images')?->getUrl()); ?>" class="w-full aspect-auto object-cover shadow-lg cursor-pointer"
                     x-show="shown"
                     x-transition:enter="transition linear duration-700"
                     x-transition:enter-start="opacity-0 scale-50"
                     x-transition:enter-end="opacity-100 scale-100">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <!--[if BLOCK]><![endif]--><?php if($currentPage?->hasMorePages()): ?>
        <div
            x-data="{
                observe() {
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('loadMore');
                            }
                        });
                    });

                    observer.observe(this.$el);
                }
            }"
            x-init="observe"
            class="h-4">
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/livewire/infinite-image-list.blade.php ENDPATH**/ ?>