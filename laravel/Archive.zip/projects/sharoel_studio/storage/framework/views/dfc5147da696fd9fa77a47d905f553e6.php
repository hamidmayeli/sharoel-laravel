
<?php if (isset($component)) { $__componentOriginalf526a6a29e9224502b0a2b3a445573bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf526a6a29e9224502b0a2b3a445573bf = $attributes; } ?>
<?php $component = App\View\Components\AdminDashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminDashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto p-6">
        <h1 class="text-2xl font-bold mb-4"><?php echo e(__('Plans')); ?></h1>
        <div class="overflow-x-auto mb-5">
            <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                <thead>
                <tr class="bg-gray-100 border-b">
                    <th class="text-left px-6 py-3 text-sm font-medium text-gray-700">#</th>
                    <th class="text-left px-6 py-3 text-sm font-medium text-gray-700">Name</th>
                    <th class="text-left px-6 py-3 text-sm font-medium text-gray-700">Price</th>
                    <th class="text-left px-6 py-3 text-sm font-medium text-gray-700">Discounted Price</th>
                    <th class="text-left px-6 py-3 text-sm font-medium text-gray-700">Discounted</th>
                    <th class="text-left px-6 py-3 text-sm font-medium text-gray-700">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-50" >
                        <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($plan->id); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-600 uppercase"><span class="whitespace-nowrap"><?php echo e($plan->name); ?> </span></td>
                        <td class="px-6 py-4 text-sm text-gray-600"><span class="whitespace-nowrap"><?php echo e($plan->price); ?></span></td>
                        <td class="px-6 py-4 text-sm text-gray-600"><span class="line-clamp-2"><?php echo e($plan->discounted_price); ?></span></td>
                        <td class="px-6 py-4 text-sm text-gray-600"><span class="whitespace-nowrap"><?php echo e($plan->is_discounted ? 'yes' : 'no'); ?> </span></td>
                        <td class="px-6 py-4 text-sm text-gray-600">
                            <a
                                href=<?php echo e(route('admin.plans.edit',['plan'=>$plan->id])); ?>

                                class="text-blue-500 hover:text-blue-700 font-medium">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf526a6a29e9224502b0a2b3a445573bf)): ?>
<?php $attributes = $__attributesOriginalf526a6a29e9224502b0a2b3a445573bf; ?>
<?php unset($__attributesOriginalf526a6a29e9224502b0a2b3a445573bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf526a6a29e9224502b0a2b3a445573bf)): ?>
<?php $component = $__componentOriginalf526a6a29e9224502b0a2b3a445573bf; ?>
<?php unset($__componentOriginalf526a6a29e9224502b0a2b3a445573bf); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/admin//plans/index.blade.php ENDPATH**/ ?>