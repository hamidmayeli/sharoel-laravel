<div x-data="map()">
    <div x-ref="map" class="map h-96">
    </div>
</div>

<?php if (! $__env->hasRenderedOnce('7262b7c9-75d1-4ffa-8417-be6c45a70099')): $__env->markAsRenderedOnce('7262b7c9-75d1-4ffa-8417-be6c45a70099'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/components/map.css']); ?>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/components/map.js']); ?>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/components/map.blade.php ENDPATH**/ ?>