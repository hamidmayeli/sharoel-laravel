<?php
    $basic = $plans->firstWhere('name', 'basic');
    $silver = $plans->firstWhere('name', 'silver');
    $gold = $plans->firstWhere('name', 'gold');
    $videography = $plans->firstWhere('name', 'videography');
?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="w-full relative h-[600px] lg:h-[1000px] overflow-hidden z-0">
        <img src=<?php echo e(asset('images/landing-main.jpeg')); ?> alt=""
             class="size-full block absolute object-cover object-center z-10">
        <span class="bg-primary/10 absolute inset-0 z-20"></span>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:p-10 xl:gap-10 p-5 gap-5">
        <div class="relative w-full rounded-xl overflow-hidden group">
            <img src=<?php echo e(asset('images/maternity.jpg')); ?> alt=""
                 class="w-full aspect-[3/4] object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold text-2xl capitalize"><?php echo e(__('maternity')); ?></span>
            </div>
        </div>
        <div class="relative w-full rounded-xl overflow-hidden group">
            <img src=<?php echo e(asset('images/newborn.jpg')); ?> alt=""
                 class="w-full aspect-[3/4] object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold text-2xl capitalize"><?php echo e(__('newBorn')); ?></span>
            </div>
        </div>
        <div class="relative w-full rounded-xl overflow-hidden group">
            <img src=<?php echo e(asset('images/children.jpeg')); ?> alt=""
                 class="w-full aspect-[3/4] object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold text-2xl capitalize"><?php echo e(__('children')); ?></span>
            </div>
        </div>
        <div class="relative w-full rounded-xl overflow-hidden group">
            <img src=<?php echo e(asset('images/in_nature.jpeg')); ?> alt=""
                 class="w-full aspect-[3/4] object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold text-2xl capitalize"><?php echo e(__('inNature')); ?></span>
            </div>
        </div>
        <div class="relative w-full rounded-xl overflow-hidden group">
            <img src=<?php echo e(asset('images/indoors.jpg')); ?> alt=""
                 class="w-full aspect-[3/4] object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold text-2xl capitalize"><?php echo e(__('indoors')); ?></span>
            </div>
        </div>
        <div class="relative w-full rounded-xl overflow-hidden group">
            <img src=<?php echo e(asset('images/family.jpg')); ?> alt=""
                 class="w-full aspect-[3/4] object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold text-2xl capitalize"><?php echo e(__('family')); ?></span>
            </div>
        </div>
    </div>
    <div class="relative overflow-hidden">
        <img class="hidden xl:block absolute inset-0" src=<?php echo e(asset('images/plans.jpg')); ?> alt="">
        <div class="hidden xl:block absolute inset-0 backdrop-blur"></div>
        <div class="flex justify-center">
            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 p-5 gap-5 relative z-10 max-w-screen-2xl">
                <div class="w-full flex flex-col bg-surface/90 border rounded-2xl p-4 space-y-5">
                    <div class="flex flex-col px-4 border-b">
                        <div class="flex justify-center mb-2">
                            <span class="text-center text-2xl font-black uppercase"><?php echo e(__('basic')); ?></span>
                        </div>
                        <div class="flex text-rose-500 text-sm justify-center font-bold gap-2 mb-4">
                            <div>
                                <?php switch(\Mcamara\LaravelLocalization\Facades\LaravelLocalization::getCurrentLocale()):
                                    case ('en'): ?>
                                        <?php echo e($basic->discount_text_en); ?>

                                        <?php break; ?>
                                    <?php case ('fa'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                    <?php case ('de'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                <?php endswitch; ?>
                            </div>
                        </div>
                        <div class="flex gap-4 items-center mb-4">
                            <div class="flex font-bold text-2xl line-through text-neutral-400">
                                <span><?php echo e($basic->price); ?></span>
                                <span>€</span>
                            </div>
                            <div class="flex font-bold text-2xl text-title">
                                <span><?php echo e($basic->discounted_price); ?></span>
                                <span>€</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">1,5</span>
                        <span><?php echo e(__('hour photo session')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">3</span>
                        <span><?php echo e(__('outfits from my Studio or your Side')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">6</span>
                        <span><?php echo e(__('professionally retouched high-quality images as digital files')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">1</span>
                        <span><?php echo e(__('professionally retouched high-quality printed image')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">5</span>
                        <span><?php echo e(__('not edited images as digital files')); ?></span>
                    </div>
                    <div class="flex items-center p-4">
                        <a  href="https://wa.me/+491629363405" class="block text-primary bg-on-primary w-full py-4 hover:text-on-primary hover:bg-primary rounded-lg border-primary border capitalize text-center">
                            <?php echo e(__('make an appointment now')); ?>

                        </a>
                    </div>
                </div>
                <div class="w-full flex flex-col bg-surface/90 border rounded-2xl p-4 space-y-5">
                    <div class="flex flex-col px-4 border-b">
                        <div class="flex justify-center mb-2">
                            <span class="text-center text-2xl font-black text-stone-400 uppercase"><?php echo e(__('silver')); ?></span>
                        </div>
                        <div class="flex text-rose-500 text-sm justify-center font-bold gap-2 mb-4">
                            <div>
                                <?php switch(\Mcamara\LaravelLocalization\Facades\LaravelLocalization::getCurrentLocale()):
                                    case ('en'): ?>
                                        <?php echo e($basic->discount_text_en); ?>

                                        <?php break; ?>
                                    <?php case ('fa'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                    <?php case ('de'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                <?php endswitch; ?>
                            </div>
                        </div>
                        <div class="flex gap-4 items-center mb-4">
                            <div class="flex font-bold text-2xl line-through text-neutral-400">
                                <span><?php echo e($silver->price); ?></span>
                                <span>€</span>
                            </div>
                            <div class="flex font-bold text-2xl text-title">
                                <span><?php echo e($silver->discounted_price); ?></span>
                                <span>€</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">2,5</span>
                        <span><?php echo e(__('hour photo session')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">4</span>
                        <span><?php echo e(__('outfits from my Studio or your Side')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">12</span>
                        <span><?php echo e(__('professionally retouched high-quality images as digital files')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">2</span>
                        <span><?php echo e(__('professionally retouched high-quality printed image')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">10</span>
                        <span><?php echo e(__('not edited images as digital files')); ?></span>
                    </div>
               <div class="flex items-center p-4">
                        <a  href="https://wa.me/+491629363405" class="block text-primary bg-on-primary w-full py-4 hover:text-on-primary hover:bg-primary rounded-lg border-primary border capitalize text-center">
                            <?php echo e(__('make an appointment now')); ?>

                        </a>
                    </div>
                </div>
                <div class="w-full flex flex-col bg-surface/90 border rounded-2xl p-4 space-y-5">
                    <div class="flex flex-col px-4 border-b">
                        <div class="flex justify-center mb-2">
                            <span class="text-center text-2xl font-black text-yellow-700 uppercase"><?php echo e(__('gold')); ?></span>
                        </div>
                        <div class="flex text-rose-500 text-sm justify-center font-bold gap-2 mb-4">
                            <div>
                                <?php switch(\Mcamara\LaravelLocalization\Facades\LaravelLocalization::getCurrentLocale()):
                                    case ('en'): ?>
                                        <?php echo e($basic->discount_text_en); ?>

                                        <?php break; ?>
                                    <?php case ('fa'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                    <?php case ('de'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                <?php endswitch; ?>
                            </div>
                        </div>
                        <div class="flex gap-4 items-center mb-4">
                            <div class="flex font-bold text-2xl line-through text-neutral-400">
                                <span><?php echo e($gold->price); ?></span>
                                <span>€</span>
                            </div>
                            <div class="flex font-bold text-2xl text-title">
                                <span><?php echo e($gold->discounted_price); ?></span>
                                <span>€</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">3,5</span>
                        <span><?php echo e(__('hour photo session')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">5</span>
                        <span><?php echo e(__('outfits from my Studio or your Side')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">18</span>
                        <span><?php echo e(__('professionally retouched high-quality images as digital files')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">3</span>
                        <span><?php echo e(__('professionally retouched high-quality printed image')); ?></span>
                    </div>
                    <div class="flex gap-2">
                        <span class="font-bold">15</span>
                        <span><?php echo e(__(('not edited images as digital files'))); ?></span>
                    </div>
               <div class="flex items-center p-4">
                        <a  href="https://wa.me/+491629363405" class="block text-primary bg-on-primary w-full py-4 hover:text-on-primary hover:bg-primary rounded-lg border-primary border capitalize text-center">
                            <?php echo e(__('make an appointment now')); ?>

                        </a>
                    </div>
                </div>
                <div class="w-full flex flex-col bg-surface/90 border rounded-2xl p-4 space-y-5">
                    <div class="flex flex-col px-4 border-b">
                        <div class="flex justify-center mb-2">
                            <span class="text-center text-2xl font-black uppercase"><?php echo e(__('videography')); ?></span>
                        </div>
                        <div class="flex text-rose-500 text-sm justify-center font-bold gap-2 mb-4">
                            <div>
                                <?php switch(\Mcamara\LaravelLocalization\Facades\LaravelLocalization::getCurrentLocale()):
                                    case ('en'): ?>
                                        <?php echo e($basic->discount_text_en); ?>

                                        <?php break; ?>
                                    <?php case ('fa'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                    <?php case ('de'): ?>
                                        <?php echo e($basic->discount_text_fa); ?>

                                        <?php break; ?>
                                <?php endswitch; ?>
                            </div>
                        </div>
                        <div class="flex gap-4 items-center mb-4">
                            <div class="flex font-bold text-2xl line-through text-neutral-400">
                                <span><?php echo e($videography->price); ?></span>
                                <span>€</span>
                            </div>
                            <div class="flex font-bold text-2xl text-title">
                                <span><?php echo e($videography->discounted_price); ?></span>
                                <span>€</span>
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center justify-center gap-2 flex-1 text-xl">
                        <span class="font-bold">2</span>
                        <span><?php echo e(__('minutes long video')); ?></span>
                    </div>
               <div class="flex items-center p-4">
                        <a  href="https://wa.me/+491629363405" class="block text-primary bg-on-primary w-full py-4 hover:text-on-primary hover:bg-primary rounded-lg border-primary border capitalize text-center">
                            <?php echo e(__('make an appointment now')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('app.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/app/home.blade.php ENDPATH**/ ?>