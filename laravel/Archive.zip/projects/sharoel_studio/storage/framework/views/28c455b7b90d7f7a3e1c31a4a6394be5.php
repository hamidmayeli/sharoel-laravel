<?php if (isset($component)) { $__componentOriginalf526a6a29e9224502b0a2b3a445573bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf526a6a29e9224502b0a2b3a445573bf = $attributes; } ?>
<?php $component = App\View\Components\AdminDashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminDashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf526a6a29e9224502b0a2b3a445573bf)): ?>
<?php $attributes = $__attributesOriginalf526a6a29e9224502b0a2b3a445573bf; ?>
<?php unset($__attributesOriginalf526a6a29e9224502b0a2b3a445573bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf526a6a29e9224502b0a2b3a445573bf)): ?>
<?php $component = $__componentOriginalf526a6a29e9224502b0a2b3a445573bf; ?>
<?php unset($__componentOriginalf526a6a29e9224502b0a2b3a445573bf); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>