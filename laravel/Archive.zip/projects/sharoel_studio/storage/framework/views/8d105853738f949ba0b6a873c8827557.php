<?php if (isset($component)) { $__componentOriginalf526a6a29e9224502b0a2b3a445573bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf526a6a29e9224502b0a2b3a445573bf = $attributes; } ?>
<?php $component = App\View\Components\AdminDashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminDashboardLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('gallery', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-174065415-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf526a6a29e9224502b0a2b3a445573bf)): ?>
<?php $attributes = $__attributesOriginalf526a6a29e9224502b0a2b3a445573bf; ?>
<?php unset($__attributesOriginalf526a6a29e9224502b0a2b3a445573bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf526a6a29e9224502b0a2b3a445573bf)): ?>
<?php $component = $__componentOriginalf526a6a29e9224502b0a2b3a445573bf; ?>
<?php unset($__componentOriginalf526a6a29e9224502b0a2b3a445573bf); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/admin/gallery/index.blade.php ENDPATH**/ ?>