
<div class="grid grid-cols-3 lg:grid-cols-3 p-5 gap-5 max-w-3xl mx-auto" x-data="{ shown: false }" x-intersect="shown = true">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('categories.show',$category)); ?>" class="relative aspect-[3/4] rounded-xl overflow-hidden group">
            <img src=<?php echo e($category->mainImage?->getFirstMedia('images')?->getUrl()); ?> alt=""
                 class="size-full  object-cover transition-transform duration-300 ease-in-out group-hover:scale-105 cursor-pointer">
            <div class="absolute inset-0 p-3 bg-primary/20 group-hover:bg-primary/5 transition-ally duration-300 flex flex-col justify-end pointer-events-none">
                <span class=" block mb-2 text-on-primary font-bold md:text-2xl capitalize"><?php echo e(__($category->slug)); ?></span>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/app/home/partials/categories.blade.php ENDPATH**/ ?>