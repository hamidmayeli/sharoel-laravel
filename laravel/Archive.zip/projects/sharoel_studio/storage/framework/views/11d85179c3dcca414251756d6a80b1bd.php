<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mt-20">
        <?php if (isset($component)) { $__componentOriginalef01a91168a4da2e34093d402e425370 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef01a91168a4da2e34093d402e425370 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.map','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('map'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef01a91168a4da2e34093d402e425370)): ?>
<?php $attributes = $__attributesOriginalef01a91168a4da2e34093d402e425370; ?>
<?php unset($__attributesOriginalef01a91168a4da2e34093d402e425370); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef01a91168a4da2e34093d402e425370)): ?>
<?php $component = $__componentOriginalef01a91168a4da2e34093d402e425370; ?>
<?php unset($__componentOriginalef01a91168a4da2e34093d402e425370); ?>
<?php endif; ?>
    </div>
    <div class="flex justify-center">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 py-10 w-full px-5 xl:w-2/3">
            <div class="w-full border border-outline rounded flex flex-col justify-start py-10 items-center">
                <svg class="w-14 mb-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve"><path fill="#282D33" d="M117.426 116.718H10.569c-4.059 0-7.362-3.338-7.362-7.441V85.604c-.168-.967.919-2.694 7.219-12.704 2.912-4.627 8.598-13.581 13.954-21.56l3.321 2.229C19.135 66.329 8.81 82.946 7.207 85.727v23.55c0 1.897 1.508 3.441 3.362 3.441h106.857c1.856 0 3.366-1.544 3.366-3.441V85.424c-.404-1.157-3.45-6.635-21.854-32.152l3.244-2.34c22.609 31.349 22.609 33.128 22.609 34.306v24.039c.001 4.103-3.304 7.441-7.365 7.441z"/><path fill="#282D33" d="M34.407 89.155H10.569c-2.897 0-5.535-1.736-6.721-4.424l3.66-1.615c.546 1.239 1.748 2.039 3.061 2.039h23.838v4zM117.424 89.155H93.393v-4h24.031c1.317 0 2.521-.8 3.066-2.037l3.66 1.611c-1.182 2.689-3.823 4.426-6.726 4.426z"/><path fill="#282D33" d="M63.998 110.815c-18.011 0-32.664-14.854-32.664-33.11 0-18.258 14.653-33.111 32.664-33.111 18.011 0 32.664 14.853 32.664 33.111 0 18.257-14.653 33.11-32.664 33.11zm0-62.221c-15.806 0-28.664 13.059-28.664 29.111s12.858 29.11 28.664 29.11 28.664-13.059 28.664-29.11-12.858-29.111-28.664-29.111z"/><path fill="#282D33" d="M63.05 97.355a19.205 19.205 0 0 1-4.393-.731l1.111-3.842c1.126.325 2.296.52 3.477.577l-.195 3.996zm4.44-.294-.725-3.934a15.177 15.177 0 0 0 3.367-1.038l1.615 3.66a19.114 19.114 0 0 1-4.257 1.312zm-12.941-2.165a19.53 19.53 0 0 1-3.596-2.617l2.707-2.945a15.462 15.462 0 0 0 2.857 2.08l-1.968 3.482zm21.034-1.401L73.177 90.3a15.54 15.54 0 0 0 2.563-2.435l3.066 2.568a19.538 19.538 0 0 1-3.223 3.062zm-27.539-4.569a19.666 19.666 0 0 1-2.085-3.922l3.721-1.467c.434 1.099.993 2.15 1.662 3.125l-3.298 2.264zm33.217-2.197-3.564-1.816c.538-1.055.956-2.17 1.244-3.316l3.879.975a19.787 19.787 0 0 1-1.559 4.157zm-36.457-6.012a20.088 20.088 0 0 1-.176-4.429l3.99.283a16.152 16.152 0 0 0 .141 3.544l-3.955.602zm38.609-2.546-4-.082.005-.384a16.156 16.156 0 0 0-.313-3.157l3.922-.787c.259 1.288.391 2.615.392 3.942l-.006.468zm-34.155-5.086-3.828-1.16a19.73 19.73 0 0 1 1.759-4.078l3.472 1.986a15.753 15.753 0 0 0-1.403 3.252zm28.764-1.906a15.787 15.787 0 0 0-1.811-3.042l3.186-2.418a19.791 19.791 0 0 1 2.27 3.813l-3.645 1.647zm-25.268-4.2-2.938-2.715a19.702 19.702 0 0 1 3.365-2.901l2.251 3.308a15.646 15.646 0 0 0-2.678 2.308zm21.015-1.4a15.46 15.46 0 0 0-2.954-1.937l1.795-3.575a19.505 19.505 0 0 1 3.72 2.439l-2.561 3.073zm-15.212-2.544L57.126 59.3a19.13 19.13 0 0 1 4.318-1.098l.527 3.965a15.077 15.077 0 0 0-3.414.868zm8.946-.597a15.306 15.306 0 0 0-3.505-.406v-4c1.493 0 2.981.172 4.423.513l-.918 3.893zM121.066 37.515C109.338 23.598 88.585 15.31 65.503 15.31h-.337c-24.285-.546-46.052 7.741-58.246 22.202l-3.058-2.578c12.966-15.378 35.901-24.223 61.343-23.623h.352c24.196 0 46.089 8.818 58.568 23.626l-3.059 2.578z"/><path fill="#282D33" d="m96.964 37.896-3.916-.818c.103-.488-.01-.739-.133-.921-.464-.685-1.821-1.283-3.633-1.6-3.811-.685-17.134-1.378-25.331-1.618-8.153.241-21.419.933-25.228 1.612-1.815.319-3.173.917-3.637 1.601-.124.182-.237.435-.136.927l-3.918.806c-.298-1.449-.04-2.825.746-3.981 1.123-1.652 3.225-2.759 6.248-3.291 4.186-.746 17.911-1.439 25.867-1.673l.058-.002.059.002c8 .233 21.787.928 25.972 1.68 3.019.529 5.122 1.638 6.245 3.294.784 1.156 1.039 2.533.737 3.982z"/><path fill="#282D33" d="M31.558 54.536H4.882C2.189 54.534 0 52.324 0 49.608V39.371c0-2.716 2.19-4.926 4.882-4.926h14.297v4H4.882c-.486-.001-.882.415-.882.926v10.238c0 .511.396.927.883.927h26.675c.487 0 .883-.416.883-.926V39.371c0-.511-.396-.926-.883-.926h-6.227v-4h6.227c2.692 0 4.883 2.21 4.883 4.926V49.61c0 2.716-2.191 4.926-4.883 4.926zM123.115 54.536H96.439c-2.691 0-4.881-2.21-4.881-4.926V39.371c0-2.716 2.189-4.926 4.881-4.926h6.228v4h-6.228c-.485 0-.881.416-.881.926V49.61c0 .511.396.926.881.926h26.676c.488 0 .885-.416.885-.926V39.371c0-.511-.396-.926-.885-.926H108.82v-4h14.295c2.693 0 4.885 2.21 4.885 4.926V49.61c0 2.716-2.191 4.926-4.885 4.926z"/></svg>
                <span class="block mb-5 uppercase"><?php echo e(__('phone')); ?></span>
                <div class="text-center">
                    <span>+491629363405</span>
                </div>
            </div>
            <div class="w-full border border-outline rounded flex flex-col justify-start py-10 items-center">
                <svg class="w-14 mb-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" xml:space="preserve"><path fill="#282D33" d="M82.141 18.8 67.334 6.194c-1.804-1.532-4.854-1.532-6.658.001L46.732 18.068l-2.603-3.058L58.075 3.138C61.342.36 66.662.359 69.934 3.136l14.808 12.606-2.601 3.058zM125.981 126.947H2.016a2.007 2.007 0 0 1-2.007-2.008V53.688a2.003 2.003 0 0 1 .269-1.198c.162-.284.389-.526.66-.705l12.566-10.699 2.602 3.058L4.023 54.43v68.503h119.952V54.419l-12.267-10.445 2.603-3.057 12.826 10.923c.362.257.638.628.768 1.059.085.266.114.547.085.826v71.215a2.01 2.01 0 0 1-2.009 2.007z"/><path fill="#282D33" d="M114.607 56.248h-4.014V19.272H16.8v36.976h-4.014v-40.99h101.821z"/><path fill="#282D33" d="M83.827 92.721H44.179c-.464 0-.913-.161-1.272-.455L.585 57.603l2.543-3.105 41.767 34.209h38.218l41.93-34.212 2.538 3.111-42.484 34.663a2.012 2.012 0 0 1-1.27.452z"/><path fill="#282D33" d="m6.993 125.504-2.602-3.058 13.793-11.73 10.4-8.929a3961.47 3961.47 0 0 0 4.429-3.804l10.31-8.846 2.614 3.047-10.309 8.845a2208.46 2208.46 0 0 1-4.432 3.805l-10.405 8.934-13.798 11.736zM122.06 126.503l-25.25-21.67a2276.798 2276.798 0 0 1-4.432-3.804l-10.306-8.844 2.614-3.047 10.308 8.845c1.604 1.38 3.208 2.758 4.428 3.802l25.253 21.672-2.615 3.046z"/><g><path fill="#282D33" d="M64.778 77.373c-13.085 0-23.73-10.628-23.73-23.69s10.646-23.689 23.73-23.689a23.674 23.674 0 0 1 18.357 8.68l-3.104 2.548a19.672 19.672 0 0 0-15.254-7.213c-10.872 0-19.716 8.826-19.716 19.675 0 10.85 8.844 19.676 19.716 19.676 4.326 0 8.436-1.375 11.884-3.976l2.417 3.205a23.564 23.564 0 0 1-14.3 4.784z"/><path fill="#282D33" d="M60.857 65.311c-.001 0-.001 0 0 0-.934 0-1.921-.148-2.936-.439-3.035-.871-5.333-3.403-6.147-6.773-1.102-4.561.581-9.612 4.389-13.185 3.331-3.123 7.874-3.778 11.099-3.778 2.703 0 4.727.453 4.811.472l2.105.479-.63 2.064c-.161.524-3.934 12.875-4.604 14.801-1.411 4.04-4.358 6.359-8.087 6.359zm6.405-20.162c-2.5 0-5.979.467-8.352 2.692-3.296 3.091-3.832 6.837-3.233 9.313.477 1.978 1.699 3.383 3.353 3.857a6.68 6.68 0 0 0 1.827.283c2.493 0 3.711-1.993 4.294-3.666.478-1.369 2.717-8.649 3.869-12.405a21.51 21.51 0 0 0-1.758-.074z"/><path fill="#282D33" d="M73.932 65.097c-2.05 0-3.946-.705-5.454-2.074-3.106-2.818-.963-12.375.593-17.82l3.859 1.102c-1.728 6.061-2.545 12.632-1.716 13.787 1.484 1.341 3.371 1.091 4.686.637 3.038-1.046 6.531-4.536 7.329-9.182.579-3.372-.066-8.454-6.433-13.521l2.499-3.141c8.32 6.621 8.515 13.707 7.891 17.342-.953 5.544-5.056 10.602-9.979 12.299-1.111.381-2.215.57-3.275.571z"/></g></svg>
                <span class="block mb-5 uppercase"><?php echo e(__('e-mail')); ?></span>
                <div class="text-center">
                    <span class="uppercase">sharoelstudio@gmail.com</span>
                </div>
            </div>
            <div class="w-full border border-outline rounded flex flex-col justify-start py-10 items-center">
                <svg class="w-14 mb-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><path d="m102.128 96.851 6.3 14.173a1.75 1.75 0 1 0 3.2-1.422l-6.3-14.173a1.75 1.75 0 1 0-3.2 1.422z"/><path d="m123.1 120.649-17.69-39.811a1.75 1.75 0 0 0-1.6-1.039H83.831C89.219 71.13 93.938 62 96.778 53.651a43.164 43.164 0 0 0 2.657-13.466 35.436 35.436 0 1 0-70.871 0 43.174 43.174 0 0 0 2.657 13.467c2.84 8.353 7.56 17.478 12.948 26.147H24.19a1.75 1.75 0 0 0-1.6 1.039L4.9 120.649a1.75 1.75 0 0 0 1.6 2.461h115a1.75 1.75 0 0 0 1.6-2.461zM32.064 40.186a31.936 31.936 0 1 1 63.871 0 39.8 39.8 0 0 1-2.471 12.34c-3.041 8.945-8.311 18.822-14.24 28.026l-.037.058A194.664 194.664 0 0 1 64 101.136a194.667 194.667 0 0 1-15.188-20.525c-.013-.02-.024-.04-.038-.059-5.929-9.2-11.2-19.081-14.239-28.025a39.812 39.812 0 0 1-2.471-12.341zM9.192 119.61 25.327 83.3H46.4a194.324 194.324 0 0 0 16.29 21.663 1.75 1.75 0 0 0 2.629 0A194.313 194.313 0 0 0 81.6 83.3h21.068l16.135 36.311z"/><path d="M64 58.775a18.592 18.592 0 1 0-18.592-18.591A18.613 18.613 0 0 0 64 58.775zm0-33.684a15.092 15.092 0 1 1-15.092 15.093A15.109 15.109 0 0 1 64 25.092z"/></svg>
                <span class="block mb-5 uppercase"><?php echo e(__('location')); ?></span>
                <div class="text-center">
                    <span class="uppercase">Rosmarinstraße 33, 40235, Düsseldorf</span>
                </div>
            </div>
        </div>
    </div>
    <div class="flex flex-col items-center text-center">
        <span class="text-3xl uppercase font-black mb-2"><?php echo e(__('contact')); ?></span>
        <span><?php echo e(__('leave a message and we will call or email you back')); ?></span>
    </div>
    <div class="flex justify-center">
        <form method="post" action="<?php echo e(route('admin.comments.store')); ?>" class="w-full flex flex-col lg:grid lg:grid-cols-2 gap-10 lg:w-3/5 p-5">
            <?php echo csrf_field(); ?>
            <div>
                <?php if (isset($component)) { $__componentOriginala753fcf7813d72af3b81e4b56ec82779 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala753fcf7813d72af3b81e4b56ec82779 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fancy-text-input','data' => ['placeholder' => ''.e(strtoupper(__('name'))).'','id' => 'name','class' => 'block w-full','type' => 'text','name' => 'name','value' => old('name'),'required' => true,'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fancy-text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(strtoupper(__('name'))).'','id' => 'name','class' => 'block w-full','type' => 'text','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name')),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $attributes = $__attributesOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $component = $__componentOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__componentOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div>
                <?php if (isset($component)) { $__componentOriginala753fcf7813d72af3b81e4b56ec82779 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala753fcf7813d72af3b81e4b56ec82779 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fancy-text-input','data' => ['placeholder' => ''.e(strtoupper(__('e-mail'))).'','id' => 'email','class' => 'block w-full','type' => 'email','name' => 'email','value' => old('email'),'required' => true,'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fancy-text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(strtoupper(__('e-mail'))).'','id' => 'email','class' => 'block w-full','type' => 'email','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $attributes = $__attributesOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $component = $__componentOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__componentOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div>
                <?php if (isset($component)) { $__componentOriginala753fcf7813d72af3b81e4b56ec82779 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala753fcf7813d72af3b81e4b56ec82779 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fancy-text-input','data' => ['placeholder' => ''.e(strtoupper(__('phone number'))).'','id' => 'phone','class' => 'block w-full','type' => 'text','name' => 'phone','value' => old('phone'),'required' => true,'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fancy-text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(strtoupper(__('phone number'))).'','id' => 'phone','class' => 'block w-full','type' => 'text','name' => 'phone','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('phone')),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $attributes = $__attributesOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $component = $__componentOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__componentOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('phone')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('phone'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div>
                <?php if (isset($component)) { $__componentOriginala753fcf7813d72af3b81e4b56ec82779 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala753fcf7813d72af3b81e4b56ec82779 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fancy-text-input','data' => ['placeholder' => ''.e(strtoupper(__('subject'))).'','id' => 'subject','class' => 'block w-full','type' => 'text','name' => 'subject','value' => old('subject'),'required' => true,'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fancy-text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(strtoupper(__('subject'))).'','id' => 'subject','class' => 'block w-full','type' => 'text','name' => 'subject','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('subject')),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $attributes = $__attributesOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__attributesOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala753fcf7813d72af3b81e4b56ec82779)): ?>
<?php $component = $__componentOriginala753fcf7813d72af3b81e4b56ec82779; ?>
<?php unset($__componentOriginala753fcf7813d72af3b81e4b56ec82779); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('subject')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('subject'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div class="col-span-2">
                <?php if (isset($component)) { $__componentOriginalab11adc2a1658641683c68330fd3fae9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab11adc2a1658641683c68330fd3fae9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.fancy-text-area','data' => ['placeholder' => ''.e(strtoupper(__('message'))).'','id' => 'message','class' => 'block w-full','type' => 'text','name' => 'message','value' => old('message'),'required' => true,'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fancy-text-area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => ''.e(strtoupper(__('message'))).'','id' => 'message','class' => 'block w-full','type' => 'text','name' => 'message','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('message')),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab11adc2a1658641683c68330fd3fae9)): ?>
<?php $attributes = $__attributesOriginalab11adc2a1658641683c68330fd3fae9; ?>
<?php unset($__attributesOriginalab11adc2a1658641683c68330fd3fae9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab11adc2a1658641683c68330fd3fae9)): ?>
<?php $component = $__componentOriginalab11adc2a1658641683c68330fd3fae9; ?>
<?php unset($__componentOriginalab11adc2a1658641683c68330fd3fae9); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('message')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('message'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
            <div class="flex items-center w-full">
                <button class="text-on-primary w-full py-4 rounded-lg bg-primary uppercase"><?php echo e(__('send your message')); ?></button>
            </div>
        </form>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/sabziyan/projects/sharoel_studio/resources/views/app/contact/index.blade.php ENDPATH**/ ?>